package com.mycoronademo.coronawebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoronawebappApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoronawebappApplication.class, args);
	}

}
