package com.mycoronademo.coronawebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoronawebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
