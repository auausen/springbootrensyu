package net.javalearn.springbootthymeleadcrudwebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootThymeleadCrudWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootThymeleadCrudWebAppApplication.class, args);
	}

}
