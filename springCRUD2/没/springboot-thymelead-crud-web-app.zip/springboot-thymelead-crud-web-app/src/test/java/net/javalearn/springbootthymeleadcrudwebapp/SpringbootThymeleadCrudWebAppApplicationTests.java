package net.javalearn.springbootthymeleadcrudwebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootThymeleadCrudWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
