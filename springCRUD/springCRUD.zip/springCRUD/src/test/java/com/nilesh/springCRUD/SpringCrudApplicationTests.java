package com.nilesh.springCRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
